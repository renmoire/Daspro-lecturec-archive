
# ! Nama: Irenia Maissa Kamila
# ! NIM: 2506031
# ! Kelas: 1B

nilai = int(input("Masukan nilai di sini: "))

if nilai >= 90 and nilai <= 100:
    print("Nilai adalah A")
if nilai >= 80 and nilai < 90:
    print("Nilai adalah B")
if nilai >= 70 and nilai < 80:
    print("Nilai adalah C")
if nilai < 70:
    print("Nilai adalah D")
else:
    print("Apa coba")
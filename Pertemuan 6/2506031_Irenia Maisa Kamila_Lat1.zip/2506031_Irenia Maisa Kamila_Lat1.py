
# ! Nama: Irenia Maissa Kamila
# ! NIM: 2506031
# ! Kelas: 1B

bilangan = int(input("Coba masukkan nilai: "))
if bilangan % 2 == 0:
    print("Bilangan adalah genap")
else:
    print("Bilangan adalah ganjil.")
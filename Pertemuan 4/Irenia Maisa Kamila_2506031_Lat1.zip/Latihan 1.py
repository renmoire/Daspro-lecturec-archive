# Nama: Irenia Maisa Kamila
# Kelas: 1B
# NIM: 2506031

angka = [10,20, 20, 30, 40, 50, 50, 60]
a = list(set(angka))
a.sort()
print(a)
# Nama: Irenia Maisa Kamila
# NIM: 2506031
# Kelas: 1B

nilai = [88, 75, 63, 97, 82, 74, 91, 80, 81, 63]

urutan = sorted(nilai, reverse=True)
print("Urutan nilai dari yang tertinggi ke yang terendah:")
print(urutan)

angkaterbesar = urutan[1:2]
print("Nilai kedua yang terbesar:")
print(angkaterbesar)
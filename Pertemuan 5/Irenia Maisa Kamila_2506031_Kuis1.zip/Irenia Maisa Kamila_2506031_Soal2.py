# Nama: Irenia Maisa Kamila
# NIM: 2506031
# Kelas: 1B
# Paket soal 1C




panjang = 100 #m
lebar = 4800 #cm
putaran = 10

lebar1 = lebar / 100

kpp = panjang * lebar1
print("Diketahui Bu Rinda lari:\n1. Putaran: 10x")
print(f"2. Running tracknya memiliki:\n  - Panjang: {panjang} m\n  - Lebar: {lebar} cm\n    Maka tkelilingnya adalah {int(kpp)} m^2")

jaraktempuh =  (kpp * 10) / 100 #dibagi 100 karena diubah ke kilometer 
print(f"Total jarak yang ditempuh Bu Rinda adalah {int(jaraktempuh)} km")
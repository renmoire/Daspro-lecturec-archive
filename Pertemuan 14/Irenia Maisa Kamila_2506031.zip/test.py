
#? Nama: Irenia Maisa Kamila
#? NIM: 2506031
#? Kelas: 1B

import pandas as pd

# Membuat DataFrame dari csv
df = pd.read_csv('insurance.csv')
print("DataFrame dari CSV:")
print(df.head())

# Melihat jumlah baris dan kolom
print("\nJumlah baris dan kolom:")
print(df.shape)

csvfile = pd.read_csv("insurance.csv")
dfsort = csvfile.sort_values(by=['sex'])
dfdesc = csvfile.sort_values(by=['sex'], ascending=False)
print("Hasil filter: \n", dfdesc.head())



groupingfile = csvfile.groupby('sex').agg(average_age = ('age', 'mean'),
                                          median_expenses = ('expenses', 'median'))
print("Hasil filter: \n", groupingfile.head())



addcolumn = csvfile['discount_expenses'] = csvfile['expenses']*0.05
print("Hasil filter: \n", csvfile.head())
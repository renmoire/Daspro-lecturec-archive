# Nama: Irenia Maisa Kamila
# NIM: 2506031
# Kelas: 1B

introduksi = "Ini adalah kalkulator pertambahan sederhana!\nSilakan memasukan sebanyak 3 angka yang ingin Anda hitung."
print(introduksi)

a = int(input("Masukan angka ke-1: "))
b = int(input("Masukan angka ke-2: "))
c = int(input("Masukan angka ke-3: "))

print(f"Hasil perhitungan {a} + {b} + {c} = {a+b+c}")
# Nama: Irenia Maisa Kamila
# NIM: 2506031
# Kelas: 1B


nama = input("Masukan nama Anda: ")
tahunlahir = int(input("Masukan tahun lahirmu: "))
umur = int(input("Masukan umur anda: "))
print(f"Halo, {nama}. Umurmu adalah {umur}, lahir di tahun {tahunlahir}.")

#! Nama: Irenia Maisa Kamila
#! NIM: 2506031
#! Kelas: 1B


for k5 in range(1, 51):
    if k5 % 5 == 0:
        print(k5)